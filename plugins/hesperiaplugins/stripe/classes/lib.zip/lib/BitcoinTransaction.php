<?php

namespace HesperiaPlugins\Stripe\Classes\lib;

/**
 * Class BitcoinTransaction
 *
 * @package Stripe
 */
class BitcoinTransaction extends ApiResource
{

}
