<?php

namespace HesperiaPlugins\Stripe\Classes\lib;

/**
 * Class LoginLink
 *
 * @package Stripe
 */
class LoginLink extends ApiResource
{

}
