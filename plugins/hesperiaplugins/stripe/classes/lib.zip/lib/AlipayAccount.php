<?php

namespace HesperiaPlugins\Stripe\Classes\lib;

/**
 * Class AlipayAccount
 *
 * @package Stripe
 */
class AlipayAccount extends ExternalAccount
{

}
