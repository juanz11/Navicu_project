<?php

namespace HesperiaPlugins\Stripe\Classes\lib\Error;

class Authentication extends Base
{
}
