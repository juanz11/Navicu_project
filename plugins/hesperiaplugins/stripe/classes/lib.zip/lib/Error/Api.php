<?php

namespace HesperiaPlugins\Stripe\Classes\lib\Error;

class Api extends Base
{
}
