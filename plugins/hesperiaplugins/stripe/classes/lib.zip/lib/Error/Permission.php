<?php

namespace HesperiaPlugins\Stripe\Classes\lib\Error;

class Permission extends Base
{
}
